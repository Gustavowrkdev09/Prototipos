import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyA2OLyOeCwsJw4ebFqHo93GGU7BnByreQ8",
  authDomain: "stringlab-e886a.firebaseapp.com",
  projectId: "stringlab-e886a",
  appId: "1:688351940229:web:93fcce4f27b1ce8daca3ec"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);